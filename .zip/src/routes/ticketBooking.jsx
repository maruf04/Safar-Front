import React from 'react'
import TicketBookingPage from '../components/TicketBookingPage'

const ticketBooking = () => {
  return (
    <div><TicketBookingPage/></div>
  )
}

export default ticketBooking