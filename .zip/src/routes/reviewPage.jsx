import React from 'react'
import Review from '../components/Review'

const reviewPage = () => {
  return (
    <div><Review/></div>
  )
}

export default reviewPage