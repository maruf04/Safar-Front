import React from 'react'
import SearchUser from '../components/SearchUser'
import Header from '../components/Header'

const searchUserInfo = () => {
  return (
    <div>
        <center><Header/></center>
        <SearchUser/>
    </div>
  )
}

export default searchUserInfo