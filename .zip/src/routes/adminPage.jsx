import React, { Fragment } from 'react'
import Admin from '../components/Admin'

const adminPage = () => {
  return <Fragment>
    <Admin/>
  </Fragment>
}

export default adminPage