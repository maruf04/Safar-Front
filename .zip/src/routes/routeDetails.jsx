import React from 'react'
import TrainRoute from '../components/TrainRoute'
import Header from '../components/Header'

const routeDetails = () => {
  return (
    <div>
      
      <TrainRoute/>
    </div>
  )
}

export default routeDetails