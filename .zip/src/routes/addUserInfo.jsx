//done
import React from 'react'
import AddUser from '../components/AddUser'

const addUserInfo = () => {
  return (
    <div>
      <AddUser />
    </div>
  )
}

export default addUserInfo