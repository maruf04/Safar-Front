import React from 'react'
import ShowUser from '../components/ShowUser'

const showUserInfo = () => {
  return (
    <div>
      {/* <center><h1>User Dashboard</h1></center>
      <center><b><h1>Dashboard</h1></b></center> */}
      <ShowUser/>
    </div>
  )
}

export default showUserInfo