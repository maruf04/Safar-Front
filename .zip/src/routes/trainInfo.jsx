import React from 'react'
import '../components/App.css';
import TrainInformation from '../components/TrainInformation';




const trainInformation = () => {
  return (
    <div>
       <TrainInformation />
    </div>
  )
}

export default trainInformation