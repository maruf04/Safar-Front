import React from 'react'
import TicketHistory from '../components/TicketHistory'

const ticketHistory = () => {
  return (
    <div><TicketHistory/></div>
  )
}

export default ticketHistory