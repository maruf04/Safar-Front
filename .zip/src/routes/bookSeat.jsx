//done
import React from 'react'
import BookAvailableSeat from '../components/BookAvailableSeat'
import TicketBookingPage from '../components/TicketBookingPage'

const bookSeat = () => {
  return (
    
    <div><BookAvailableSeat/></div>
  )
}

export default bookSeat