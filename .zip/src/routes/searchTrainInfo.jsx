import React from 'react'
import SearchTrain from '../components/SearchTrain'
import Header from '../components/Header'

const searchTrainInfo = () => {
  return (
    <div>
        {/* <center><Header/></center> */}
        <SearchTrain/>
    </div>
  )
}

export default searchTrainInfo;