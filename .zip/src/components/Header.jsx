import React from "react";
import './comp.css'

const Header = () => {
  return (
    <div>
      <h1 className="header-title">
        Safar
      </h1>
    </div>
  );
};

export default Header;