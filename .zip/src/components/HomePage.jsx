import './hp.css';

const HomePage = () => {
   
    const reloadPage = () =>{
        window.location.reload();
    }
};

export default HomePage;